using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class nyAIstoff2 : MonoBehaviour
{

//https://forum.unity.com/threads/make-enemy-shoot-the-player-bonus-if-you-know-how-to-work-with-hit-animation.688312/

    public Transform target; //where we want to shoot(player? mouse?)
    public Transform weaponMuzzle; //The empty game object which will be our weapon muzzle to shoot from
    public GameObject bullet; //Your set-up prefab
    public float fireRate = 3000f; //Fire every 3 seconds
    public float shootingPower = 3f; //force of projection
 
 
    private float shootingTime; //local to store last time we shot so we can make sure its done every 3s
 

 // keep a copy of the executing script
    public IEnumerator coroutine;
    public int health = 100;
    public GameObject deathEffect;
 
    void Start() {
        //Start the coroutine we define below named ExampleCoroutine.
        //StartCoroutine(ExampleCoroutine());

        //minski donetsi ja luhanska säilyy ukrainan alueilla
        //keskustelu

    }

   // float timer = 0;
    //bool timerReached = false;
    
    private void Update()
    {
        //if(!timerReached)
        //timer += Time.deltaTime;

        //if(!timerReached && timer > 2)
        //{
        Fire(); //Constantly fire
        ///timerReached = true;
        
        //}

    }

    bool once = false;
 
    private void Fire()
    {
        //if(once == true) {
        //StopCoroutine(coroutine);
        //} else {
       
        //StartCoroutine(ExampleCoroutine());
        
        //}

        if (Time.time > shootingTime)
        {
             //coroutine = WaitAndPrint(3.0f);
            //StartCoroutine(coroutine);
              shootingTime = Time.time + fireRate / 1000; //set the local var. to current time of shooting
            Vector2 myPos = new Vector2(weaponMuzzle.position.x, weaponMuzzle.position.y); //our curr position is where our muzzle points
            
            GameObject projectile = Instantiate(bullet, myPos, Quaternion.identity); //create our bullet
            //Vector2 direction = myPos - (Vector2)target.position; //get the direction to the target
            Vector2 direction = (target.transform.position - transform.position).normalized; //last movespeed
            projectile.GetComponent<Rigidbody2D>().velocity = direction * shootingPower; //shoot the bullet

        //After we have waited 5 seconds print the time again.
        //Debug.Log("Finished Coroutine at timestamp : " + Time.time);
        }
    }
 
    public void TakeDamage(int damage)
    {
        health -= damage;
 
        if (health <= 0)
        {
            Die();
        }
    }
 
    void Die()
    {
        Instantiate(deathEffect, transform.position, Quaternion.identity);
        Destroy(gameObject);
    }

        public IEnumerator WaitAndPrint(float waitTime)
    {
        //Print the time of when the function is first called.
        Debug.Log("Started Coroutine at timestamp : " + Time.time);

        //yield on a new YieldInstruction that waits for 5 seconds.
        yield return new WaitForSeconds(2);
      
    }
}
