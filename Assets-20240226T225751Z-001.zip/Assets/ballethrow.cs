using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ballethrow : MonoBehaviour
{
    public Transform fpoint;
    public GameObject ballePrefab;
    public GameObject playa;

    public float balleFrc = 200f;


    // Update is called once per frame
    void Update()
    {
        if(Input.GetButtonDown("Fire1"))
        {
            Sheet();
        }
    }
    void Sheet()
    {
        //feed the prefab we wan to creöte
        GameObject balle = Instantiate(ballePrefab, fpoint.position, fpoint.rotation);
        Rigidbody2D rb = balle.GetComponent<Rigidbody2D>();
        //balle.transform.position = playa.transform.position;
        rb.AddForce(fpoint.up * balleFrc, ForceMode2D.Impulse);
        //balle.GetComponent<Rigidbody2D>().velocity = direction * balleSpeed;

        //Addforce(fpoint.up * balleFrc, ForceMode2D.Impulse);
        

//unity top down shoo-ding
//unity point and shoot tutorial - shoo-din tk

        //Rigidbody2D rb = balle.GetComponent<Rigidbody2D>();
        //rb.Addforce(new Vector3(0, 0, 200));//fpoint.up * balleFrc);//ForceMode2D.Impulse);

    }
}
